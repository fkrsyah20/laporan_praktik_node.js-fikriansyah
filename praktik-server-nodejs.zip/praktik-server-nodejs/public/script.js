"use strict";

const elStatus = document.getElementById("status");

function tampilkanStatus(pesan, galat = false) {
  elStatus.textContent = pesan;
  elStatus.className = galat ? "galat" : "";
}

async function ambilJson(url, opsi) {
  const res = await fetch(url, opsi);
  const data = await res.json();
  if (!res.ok) throw new Error(data.pesan || "Terjadi kesalahan");
  return data;
}

async function muatProfil() {
  const p = await ambilJson("/api/profil");
  document.getElementById("p-nama").textContent = p.nama;
  document.getElementById("p-nim").textContent = p.nim;
  document.getElementById("p-prodi").textContent = p.prodi;
  document.getElementById("p-universitas").textContent = p.universitas;
}

async function muatTeknologi() {
  const daftar = await ambilJson("/api/teknologi");
  const ul = document.getElementById("daftar-teknologi");
  ul.replaceChildren(
    ...daftar.map((nama) => {
      const li = document.createElement("li");
      li.textContent = nama;
      return li;
    })
  );
}

async function muatTarget() {
  const daftar = await ambilJson("/api/target");
  const ol = document.getElementById("daftar-target");
  ol.replaceChildren(
    ...daftar.map((t) => {
      const li = document.createElement("li");
      const teks = document.createElement("span");
      teks.textContent = t.judul;
      const tombol = document.createElement("button");
      tombol.type = "button";
      tombol.className = "hapus";
      tombol.textContent = "Hapus";
      tombol.addEventListener("click", () => hapusTarget(t.id));
      li.append(teks, tombol);
      return li;
    })
  );
}

async function hapusTarget(id) {
  try {
    const hasil = await ambilJson(`/api/target/${id}`, { method: "DELETE" });
    tampilkanStatus(hasil.pesan);
    await muatTarget();
  } catch (err) {
    tampilkanStatus(err.message, true);
  }
}

document.getElementById("form-target").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("input-target");
  try {
    const baru = await ambilJson("/api/target", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ judul: input.value }),
    });
    tampilkanStatus(`Target "${baru.judul}" berhasil ditambahkan.`);
    input.value = "";
    await muatTarget();
  } catch (err) {
    tampilkanStatus(err.message, true);
  }
});

Promise.all([muatProfil(), muatTeknologi(), muatTarget()]).catch((err) =>
  tampilkanStatus("Gagal memuat data: " + err.message, true)
);
