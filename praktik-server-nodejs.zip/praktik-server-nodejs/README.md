# Praktik Server Web & REST API Sederhana (Node.js)

Muhamad Fikriansyah (24260028) - Teknik Informatika, UNUSIA

Tanpa library tambahan: tidak perlu `npm install`. Syarat: Node.js 18 atau lebih baru.

## Cara menjalankan di VS Code
1. `File > Open Folder...` lalu pilih folder `praktik-server-nodejs`.
2. Tekan **F5** (pilih "Jalankan Server (F5)"), atau buka terminal (`Ctrl + ``) lalu ketik:
   ```
   npm start
   ```
3. Buka http://localhost:3000 di browser.
4. Hentikan server dengan `Ctrl + C`.

## Perintah lain
- `npm test`  : menjalankan pengujian otomatis REST API.
- `npm run dev` : server dengan auto-restart saat kode diubah.
- Jika port 3000 dipakai: PowerShell `$env:PORT=3001; node server.js`

## Endpoint
| Metode | Alamat | Fungsi |
|---|---|---|
| GET | /api/profil | Data profil |
| GET | /api/teknologi | Daftar teknologi |
| GET | /api/target | Daftar target belajar |
| POST | /api/target | Tambah target (`{"judul": "..."}`) |
| DELETE | /api/target/:id | Hapus target |

## Catatan
- Di PowerShell, `curl` adalah alias Invoke-WebRequest. Gunakan `curl.exe` atau ekstensi REST Client (`requests.http`).
- Data disimpan di memori: daftar target kembali ke kondisi awal setiap server dijalankan ulang.
